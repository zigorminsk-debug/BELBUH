module belhub

go 1.20
