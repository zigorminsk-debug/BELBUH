//go:build windows

package main

import (
	"fmt"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

type Portal struct {
	Name, Category, URL, Note string
	Legacy                    bool
}

var portals = []Portal{
	{"МНС — официальный сайт", "Налоги и финансы", "https://nalog.gov.by/", "Новости, сервисы и нормативные материалы", false},
	{"МНС — личный кабинет", "Налоги и финансы", "https://portal.nalog.gov.by/", "Вход по ЭЦП или учетной записи", true},
	{"МНС — личный кабинет физлица", "Налоги и финансы", "https://lkfl.portal.nalog.gov.by/", "Сервисы для физических лиц", false},
	{"Министерство финансов", "Налоги и финансы", "https://www.minfin.gov.by/", "Официальный сайт Минфина", false},
	{"Единый портал финансового рынка", "Налоги и финансы", "https://portal.gov.by/", "Государственные электронные сервисы", false},
	{"Национальный банк", "Налоги и финансы", "https://www.nbrb.by/", "Курсы, статистика, нормативные документы", false},
	{"ФСЗН — корпоративный портал", "Отчетность", "https://portal2.ssf.gov.by/", "Электронные документы ФСЗН", true},
	{"ФСЗН — официальный сайт", "Отчетность", "https://ssf.gov.by/", "Фонд социальной защиты населения", false},
	{"Белстат — электронный респондент", "Отчетность", "https://e-respondent.belstat.gov.by/", "Электронная статистическая отчетность; требуется АВЕСТ", true},
	{"Белстат", "Отчетность", "https://www.belstat.gov.by/", "Официальная статистика", false},
	{"Белгосстрах", "Отчетность", "https://bgs.by/", "Официальный сайт", false},
	{"Белгосстрах — кабинет страхователя", "Отчетность", "https://lk.bgs.by/", "Электронные сервисы страхователя", false},
	{"ЕПЭУ", "Госуслуги", "https://e-pasluga.by/", "Единый портал электронных услуг", false},
	{"Личный кабинет ЕПЭУ", "Госуслуги", "https://account.gov.by/", "Вход в единый личный кабинет", false},
	{"НЦЭУ", "ЭЦП и доступ", "https://nces.by/", "Национальный центр электронных услуг", false},
	{"НЦЭУ — техподдержка", "ЭЦП и доступ", "https://helpdesk.nces.by/", "Инструкции по АВЕСТ и ГосСУОК", false},
	{"НЦЭУ — облачное хранилище", "ЭЦП и доступ", "https://store.nces.by/", "Получение комплекта абонента и сертификатов", false},
	{"АВЕСТ — загрузки", "ЭЦП и доступ", "https://www.avest.by/crypto/download/", "Только официальные версии криптографического ПО", false},
	{"ГосСУОК", "ЭЦП и доступ", "https://pki.gov.by/", "Инфраструктура открытых ключей", true},
	{"ЕГР", "Бизнес", "https://egr.gov.by/", "Единый государственный регистр юрлиц и ИП", false},
	{"Единый реестр лицензий", "Бизнес", "https://license.gov.by/", "Сведения о лицензиях", false},
	{"Портал госзакупок", "Закупки", "https://goszakupki.by/", "Электронные государственные закупки", false},
	{"Биржевая площадка БУТБ", "Закупки", "https://butb.by/", "Белорусская универсальная товарная биржа", false},
	{"Национальный правовой портал", "Право", "https://pravo.by/", "Законодательство Республики Беларусь", false},
	{"Судебные кабинеты", "Право", "https://court.gov.by/", "Система общих судов", false},
	{"Минюст", "Право", "https://minjust.gov.by/", "Официальный сайт Министерства юстиции", false},
	{"Электронная таможня", "Таможня", "https://www.customs.gov.by/electronic-customs/", "Сервисы Государственного таможенного комитета", false},
	{"Таможенный портал", "Таможня", "https://gtk.gov.by/", "Официальный сайт ГТК", false},
	{"Минтруд и соцзащиты", "Органы власти", "https://mintrud.gov.by/", "Официальный сайт", false},
	{"Минэкономики", "Органы власти", "https://economy.gov.by/", "Официальный сайт", false},
	{"Минсвязи", "Органы власти", "https://mpt.gov.by/", "Официальный сайт", false},
	{"Минобразования", "Органы власти", "https://edu.gov.by/", "Официальный сайт", false},
	{"Минздрав", "Органы власти", "https://minzdrav.gov.by/", "Официальный сайт", false},
	{"Мингорисполком", "Органы власти", "https://minsk.gov.by/", "Официальный портал Минска", false},
	{"Совет Министров", "Органы власти", "https://government.by/", "Правительство Республики Беларусь", false},
	{"Президент Республики Беларусь", "Органы власти", "https://president.gov.by/", "Официальный интернет-портал", false},
	{"Обращения.бел", "Госуслуги", "https://обращения.бел/", "Электронные обращения граждан и юридических лиц", false},
}

var (
	user32                                         = syscall.NewLazyDLL("user32.dll")
	kernel32                                       = syscall.NewLazyDLL("kernel32.dll")
	shell32                                        = syscall.NewLazyDLL("shell32.dll")
	pDefWindowProc                                 = user32.NewProc("DefWindowProcW")
	pRegisterClassEx                               = user32.NewProc("RegisterClassExW")
	pCreateWindowEx                                = user32.NewProc("CreateWindowExW")
	pShowWindow                                    = user32.NewProc("ShowWindow")
	pUpdateWindow                                  = user32.NewProc("UpdateWindow")
	pGetMessage                                    = user32.NewProc("GetMessageW")
	pTranslateMessage                              = user32.NewProc("TranslateMessage")
	pDispatchMessage                               = user32.NewProc("DispatchMessageW")
	pPostQuitMessage                               = user32.NewProc("PostQuitMessage")
	pSendMessage                                   = user32.NewProc("SendMessageW")
	pSetWindowText                                 = user32.NewProc("SetWindowTextW")
	pGetWindowText                                 = user32.NewProc("GetWindowTextW")
	pMessageBox                                    = user32.NewProc("MessageBoxW")
	pShellExecute                                  = shell32.NewProc("ShellExecuteW")
	pGetModuleHandle                               = kernel32.NewProc("GetModuleHandleW")
	hwndMain, hList, hSearch, hCat, hInfo, hStatus uintptr
	shown                                          []int
)

type WNDCLASSEX struct {
	Size                               uint32
	Style                              uint32
	WndProc                            uintptr
	ClsExtra, WndExtra                 int32
	Instance, Icon, Cursor, Background uintptr
	MenuName, ClassName                *uint16
	IconSm                             uintptr
}
type POINT struct{ X, Y int32 }
type MSG struct {
	Hwnd           uintptr
	Message        uint32
	WParam, LParam uintptr
	Time           uint32
	Pt             POINT
	Private        uint32
}

const (
	WM_CREATE           = 1
	WM_DESTROY          = 2
	WM_COMMAND          = 0x111
	WM_SIZE             = 5
	WS_OVERLAPPEDWINDOW = 0x00CF0000
	WS_VISIBLE          = 0x10000000
	WS_CHILD            = 0x40000000
	WS_BORDER           = 0x00800000
	WS_VSCROLL          = 0x00200000
	WS_TABSTOP          = 0x00010000
	LBS_NOTIFY          = 1
	CBS_DROPDOWNLIST    = 3
	ES_AUTOHSCROLL      = 0x80
	SS_LEFT             = 0
	LB_ADDSTRING        = 0x180
	LB_RESETCONTENT     = 0x184
	LB_GETCURSEL        = 0x188
	CB_ADDSTRING        = 0x143
	CB_GETCURSEL        = 0x147
	CB_SETCURSEL        = 0x14E
	CB_GETLBTEXT        = 0x148
	BN_CLICKED          = 0
	LBN_SELCHANGE       = 1
	EN_CHANGE           = 0x300
	ID_LIST             = 100
	ID_SEARCH           = 101
	ID_CAT              = 102
	ID_OPEN             = 103
	ID_EDGE             = 104
	ID_TRUST            = 105
	ID_DIAG             = 106
	ID_AVEST            = 107
	ID_UPDATE           = 108
	SW_SHOW             = 5
	MB_OK               = 0
	MB_YESNO            = 4
	IDYES               = 6
)

func w(s string) *uint16    { p, _ := syscall.UTF16PtrFromString(s); return p }
func low(v uintptr) uint16  { return uint16(v & 0xffff) }
func high(v uintptr) uint16 { return uint16((v >> 16) & 0xffff) }
func create(class, text string, style uint32, x, y, cx, cy int32, parent, id uintptr) uintptr {
	h, _, _ := pCreateWindowEx.Call(0, uintptr(unsafe.Pointer(w(class))), uintptr(unsafe.Pointer(w(text))), uintptr(style), uintptr(x), uintptr(y), uintptr(cx), uintptr(cy), parent, id, 0, 0)
	return h
}
func setText(h uintptr, s string) { pSetWindowText.Call(h, uintptr(unsafe.Pointer(w(s)))) }
func msgbox(title, text string, flags uintptr) uintptr {
	r, _, _ := pMessageBox.Call(hwndMain, uintptr(unsafe.Pointer(w(text))), uintptr(unsafe.Pointer(w(title))), flags)
	return r
}
func send(h uintptr, m uint32, a, b uintptr) uintptr {
	r, _, _ := pSendMessage.Call(h, uintptr(m), a, b)
	return r
}
func selected() *Portal {
	n := int(send(hList, LB_GETCURSEL, 0, 0))
	if n < 0 || n >= len(shown) {
		return nil
	}
	return &portals[shown[n]]
}
func field(h uintptr) string {
	b := make([]uint16, 512)
	pGetWindowText.Call(h, uintptr(unsafe.Pointer(&b[0])), 511)
	return syscall.UTF16ToString(b)
}
func shell(target string) {
	pShellExecute.Call(hwndMain, uintptr(unsafe.Pointer(w("open"))), uintptr(unsafe.Pointer(w(target))), 0, 0, SW_SHOW)
}

func refresh() {
	q := strings.ToLower(strings.TrimSpace(field(hSearch)))
	cat := field(hCat)
	send(hList, LB_RESETCONTENT, 0, 0)
	shown = nil
	for i, p := range portals {
		if (cat == "Все категории" || cat == p.Category) && (q == "" || strings.Contains(strings.ToLower(p.Name+" "+p.Note), q)) {
			shown = append(shown, i)
			label := p.Name
			if p.Legacy {
				label += "  [ЭЦП]"
			}
			send(hList, LB_ADDSTRING, 0, uintptr(unsafe.Pointer(w(label))))
		}
	}
	setText(hStatus, fmt.Sprintf("Найдено порталов: %d. BELHUB не хранит логины, пароли и закрытые ключи.", len(shown)))
}
func details() {
	p := selected()
	if p == nil {
		return
	}
	mode := "Современный браузер"
	if p.Legacy {
		mode = "Может требоваться АВЕСТ/AvCMXWebP или режим совместимости Edge"
	}
	setText(hInfo, p.Name+"\r\n"+p.Note+"\r\n"+mode+"\r\n"+p.URL)
}
func edge(p *Portal) {
	paths := []string{filepath.Join(os.Getenv("ProgramFiles(x86)"), "Microsoft", "Edge", "Application", "msedge.exe"), filepath.Join(os.Getenv("ProgramFiles"), "Microsoft", "Edge", "Application", "msedge.exe")}
	for _, x := range paths {
		if _, e := os.Stat(x); e == nil {
			exec.Command(x, p.URL).Start()
			return
		}
	}
	shell(p.URL)
}
func trusted(p *Portal) {
	u, e := url.Parse(p.URL)
	if e != nil {
		return
	}
	host := strings.TrimPrefix(u.Hostname(), "www.")
	parts := strings.Split(host, ".")
	if len(parts) < 2 {
		return
	}
	root := strings.Join(parts[len(parts)-2:], ".")
	sub := strings.Join(parts[:len(parts)-2], ".")
	key := `HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap\Domains\` + root
	if sub != "" {
		key += `\` + sub
	}
	if msgbox("Надежные сайты", "Добавить "+host+" в зону «Надежные сайты» текущего пользователя?\r\n\r\nИзменение можно удалить через Свойства браузера → Безопасность.", MB_YESNO) != IDYES {
		return
	}
	c := exec.Command("reg.exe", "add", key, "/v", "https", "/t", "REG_DWORD", "/d", "2", "/f")
	if e := c.Run(); e != nil {
		msgbox("Ошибка", e.Error(), MB_OK)
	} else {
		msgbox("Готово", host+" добавлен в надежные сайты.", MB_OK)
	}
}
func diagnostics() {
	lines := []string{"Диагностика рабочего места"}
	edgeOK := false
	for _, p := range []string{filepath.Join(os.Getenv("ProgramFiles(x86)"), "Microsoft", "Edge", "Application", "msedge.exe"), filepath.Join(os.Getenv("ProgramFiles"), "Microsoft", "Edge", "Application", "msedge.exe")} {
		if _, e := os.Stat(p); e == nil {
			edgeOK = true
		}
	}
	if edgeOK {
		lines = append(lines, "✓ Microsoft Edge найден")
	} else {
		lines = append(lines, "✗ Microsoft Edge не найден")
	}
	av := false
	for _, p := range []string{filepath.Join(os.Getenv("ProgramFiles"), "Avest"), filepath.Join(os.Getenv("ProgramFiles(x86)"), "Avest")} {
		if s, e := os.Stat(p); e == nil && s.IsDir() {
			av = true
		}
	}
	if av {
		lines = append(lines, "✓ Каталог АВЕСТ найден")
	} else {
		lines = append(lines, "! АВЕСТ не обнаружен по стандартному пути")
	}
	c := &http.Client{Timeout: 6 * time.Second}
	r, e := c.Get("https://nces.by/")
	if e == nil {
		r.Body.Close()
		lines = append(lines, "✓ HTTPS-доступ к НЦЭУ работает")
	} else {
		lines = append(lines, "✗ Проверка сети: "+e.Error())
	}
	lines = append(lines, "", "Приложение намеренно не читает личные сертификаты, токены и пароли.")
	msgbox("BELHUB — диагностика", strings.Join(lines, "\r\n"), MB_OK)
}
func wndproc(hwnd uintptr, msg uint32, wp, lp uintptr) uintptr {
	switch msg {
	case WM_CREATE:
		create("STATIC", "BELHUB — государственные порталы Беларуси", WS_CHILD|WS_VISIBLE, 18, 12, 700, 28, hwnd, 0)
		hSearch = create("EDIT", "", WS_CHILD|WS_VISIBLE|WS_BORDER|WS_TABSTOP|ES_AUTOHSCROLL, 18, 48, 300, 28, hwnd, ID_SEARCH)
		hCat = create("COMBOBOX", "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST, 330, 48, 280, 200, hwnd, ID_CAT)
		cats := map[string]bool{}
		for _, p := range portals {
			cats[p.Category] = true
		}
		a := []string{}
		for c := range cats {
			a = append(a, c)
		}
		sort.Strings(a)
		a = append([]string{"Все категории"}, a...)
		for _, c := range a {
			send(hCat, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(w(c))))
		}
		send(hCat, CB_SETCURSEL, 0, 0)
		hList = create("LISTBOX", "", WS_CHILD|WS_VISIBLE|WS_BORDER|WS_VSCROLL|WS_TABSTOP|LBS_NOTIFY, 18, 86, 592, 330, hwnd, ID_LIST)
		hInfo = create("STATIC", "Выберите портал в списке.", WS_CHILD|WS_VISIBLE|SS_LEFT, 628, 88, 330, 150, hwnd, 0)
		create("BUTTON", "Открыть", WS_CHILD|WS_VISIBLE|WS_TABSTOP, 628, 245, 155, 34, hwnd, ID_OPEN)
		create("BUTTON", "Открыть в Edge", WS_CHILD|WS_VISIBLE|WS_TABSTOP, 796, 245, 162, 34, hwnd, ID_EDGE)
		create("BUTTON", "Добавить в надежные", WS_CHILD|WS_VISIBLE|WS_TABSTOP, 628, 290, 330, 34, hwnd, ID_TRUST)
		create("BUTTON", "Диагностика", WS_CHILD|WS_VISIBLE|WS_TABSTOP, 628, 336, 155, 34, hwnd, ID_DIAG)
		create("BUTTON", "Установить АВЕСТ", WS_CHILD|WS_VISIBLE|WS_TABSTOP, 796, 336, 162, 34, hwnd, ID_AVEST)
		create("BUTTON", "Обновить сертификаты / СОС", WS_CHILD|WS_VISIBLE|WS_TABSTOP, 628, 382, 330, 34, hwnd, ID_UPDATE)
		hStatus = create("STATIC", "", WS_CHILD|WS_VISIBLE, 18, 430, 940, 25, hwnd, 0)
		refresh()
	case WM_COMMAND:
		id, code := low(wp), high(wp)
		if id == ID_SEARCH && code == EN_CHANGE {
			refresh()
		} else if id == ID_CAT {
			refresh()
		} else if id == ID_LIST && code == LBN_SELCHANGE {
			details()
		} else if code == BN_CLICKED {
			p := selected()
			switch id {
			case ID_OPEN:
				if p != nil {
					shell(p.URL)
				}
			case ID_EDGE:
				if p != nil {
					edge(p)
				}
			case ID_TRUST:
				if p != nil {
					trusted(p)
				}
			case ID_DIAG:
				go diagnostics()
			case ID_AVEST:
				shell("https://www.avest.by/crypto/download/")
			case ID_UPDATE:
				shell("https://helpdesk.nces.by/client-docs/avest/instrukciya-po-ustanovke-avest")
			}
		}
	case WM_DESTROY:
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProc.Call(hwnd, uintptr(msg), wp, lp)
	return r
}
func main() {
	inst, _, _ := pGetModuleHandle.Call(0)
	cls := w("BELHUB_MAIN")
	wc := WNDCLASSEX{Size: uint32(unsafe.Sizeof(WNDCLASSEX{})), WndProc: syscall.NewCallback(wndproc), Instance: inst, Background: 6, ClassName: cls}
	pRegisterClassEx.Call(uintptr(unsafe.Pointer(&wc)))
	hwndMain, _, _ = pCreateWindowEx.Call(0, uintptr(unsafe.Pointer(cls)), uintptr(unsafe.Pointer(w("BELHUB 1.0 — госпорталы Республики Беларусь"))), WS_OVERLAPPEDWINDOW|WS_VISIBLE, 100, 80, 1000, 520, 0, 0, inst, 0)
	if hwndMain == 0 {
		return
	}
	pShowWindow.Call(hwndMain, SW_SHOW)
	pUpdateWindow.Call(hwndMain)
	var m MSG
	for {
		r, _, _ := pGetMessage.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessage.Call(uintptr(unsafe.Pointer(&m)))
	}
}
