// Copyright 2026 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//go:build gc

package cpu

// Can only be called when the vector extension is present.
// Implemented in cpu_riscv64.s.
func readVLENB() uint
